db.myCollection.aggregate( [{$group:{_id:"$Staff_Department", sum:{$sum:1}}}] )
/*This uses the aggregate query to add up how many of each Staff_Department have tickets associated with them.
First the group operator groups the tickets by Staff_Department. 
The _id is set to display the values of the Staff_Department attribute by using $ before the attribute name. 
Then $sum aggregate operator was used to add the amount of tickets. 
This is set to 1 to display the results as positive.*/