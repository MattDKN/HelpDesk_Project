CREATE Database HelpDesk_Database;

use HelpDesk_Database;

DROP TABLE IF EXISTS Staff;

CREATE TABLE IF NOT EXISTS Staff (
	Staff_ID INT(10) NOT NULL AUTO_INCREMENT,
    Staff_Code VARCHAR(5),
    Staff_Title ENUM('Dr', 'Mr', 'Mrs', 'Miss', 'Ms'),
    Staff_Forname VARCHAR(50),
    Staff_Surname VARCHAR(50),
    Staff_Department VARCHAR(50),
    Staff_Roles VARCHAR(75),
    PRIMARY KEY (Staff_ID)
);

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('FZ', 'Dr', 'Fiona', 'Zeema', 'English', 'Head Teacher');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('JW', 'Mr', 'Jack', 'Walsh', 'English', 'Head of KS5 English');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('DP', 'Mrs', 'Deborah', 'Parker', 'English', 'Head of KS4 English');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('PD', 'Mr', 'Peter', 'Daniels', 'English', 'Head of English Department');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('SS', 'Miss', 'Sophie', 'Swift', 'English', 'Teacher');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('TJ','Mrs', 'Tracy', 'Jones', 'English', 'Teacher'); 
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('ALC', 'Mr', 'Andrew', 'Lawrence-Cunningham', 'English', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('NH', 'Mrs', 'Nicola', 'Hay', 'Maths', 'Assistant-Head Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('CF', 'Mr', 'Christopher', 'Foster', 'Maths', 'Head of KS5 Maths');
         
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('MG', 'Mr', 'Micheal', 'Gledhill', 'Maths', 'Head of Maths Department');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('ED', 'Mrs', 'Elise', 'Donaldson', 'Maths', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('LS', 'Mr', 'Liam', 'Smith', 'Maths', 'Head of KS4 Maths');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('KR', 'Mr', 'Kasper', 'Rowlinson', 'Maths', 'Teacher');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('AH', 'Mr', 'Anthony', 'Hay', 'Science', 'Head of Science Department');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('NN', 'Mr', 'Nigel', 'Newns', 'Science', 'Head of KS4 Science');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('AA', 'Ms', 'Amy', 'Armstrong', 'Science', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('AMQ', 'Mr', 'Arther', 'McQuillian', 'Science', 'Head of KS5 Science');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('CW', 'Miss', 'Caitlin', 'Walton', 'Science', 'Teacher');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('KW', 'Mrs', 'Karren', 'Wilson', 'Science', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('BJ', 'Mr', 'Benjamin', 'James', 'Humanities', 'Head of Geography Department');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('EJ', 'Mrs', 'Elizibeth', 'Jenkins', 'Humanities', 'Head of History Department');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('EC', 'Ms', 'Elaine', 'Chadwick', 'Humanities', 'Head of Religious Studies');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('PB', 'Mr', 'Patrick', 'Brown', 'Humanities', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('VA', 'Miss', 'Victoria', 'Appleton', 'Humanities' ,'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('IR', 'Miss', 'Iola', 'Roberts', 'P.E.', 'Head of KS5 Physical Education');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('CC', 'Miss', 'Chloe', 'Chadwick', 'P.E.', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('EH', 'Mrs', 'Emily', 'Hughes', 'P.E.', 'Head of Physical Education Department');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('IB', 'Mr', 'Ian', 'Braithwaite', 'P.E.', 'Head of KS4 Physical Education');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('IB', 'Mr', 'Ian', 'Braithwaite', 'P.E.', 'Head of KS4 Physical Education');
   
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('DH', 'Mr', 'David', 'Hill', 'Business, IT & Media', 'Head of IT Department');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('IF', 'Mrs', 'Isabelle', 'Fleetwood', 'Business, IT & Media', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('JH', 'Mr', 'James', 'Holden', 'Business, IT & Media', 'Head of Business Department');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('CS', 'Miss', 'Courtney', 'Sharpe', 'Psychology & Law', 'Head of KS5 Psychology & Law');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('DT', 'Mr', 'Daniel', 'Thatcher', 'Psychology & Law', 'Head of Psychology & Law Department');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('CL', 'Mr', 'Craig', 'Livingstone', 'Psychology & Law', 'Head of KS4 Psychology & Law');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('HJ', 'Ms', 'Helen', 'Jones', 'Languages', 'Head of Languages Department');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('EB', 'Ms', 'Ella', 'Burrows', 'Languages', 'Head of KS5 Languages');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('EM', 'Mrs', 'Emily', 'Muller', 'Languages', 'Head of KS4 Languages');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('TLC', 'Mr', 'Thierry', 'La Costa', 'Languages', 'Teacher');

INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('MW', 'Mr', 'Matthew', 'Whitehall', 'Languages', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('TH', 'Mr', 'Thomas', 'Harris', 'Performing Arts', 'Head of Performing Arts Department');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('JM', 'Miss', 'Jennifer', 'Myles', 'Performing Arts', 'Teacher');
        
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('RM', 'Mrs', 'Rebecca', 'Maguire', 'Performing Arts', 'Teacher');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('NC', 'Mrs', 'Nicola', 'Calderbank', 'Administration', 'Exams Officer');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('HK', 'Ms', 'Heather', 'Kannaird', 'Administration', 'Office Manager');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('RR', 'Mr', 'Ralph', 'Roberts', 'Administration', 'Finance Administrator');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('PE', 'Miss', 'Paula', 'Evans', 'Administration', 'Events Coordinator');
    
INSERT INTO Staff(Staff_Code, Staff_Title, Staff_Forname, Staff_Surname, Staff_Department, Staff_Roles)
	VALUES('EE', 'Mrs', 'Eugine', 'Edwards', 'Administration', 'Administative assistant');
    
DROP TABLE IF EXISTS IT_Staff;

CREATE TABLE IF NOT EXISTS IT_Staff (
	IT_Staff_ID INT(10) NOT NULL AUTO_INCREMENT,
    IT_Staff_Title ENUM('Dr', 'Mr', 'Mrs', 'Miss', 'Ms'),
    IT_Staff_Code VARCHAR(5),
    IT_Staff_Forname VARCHAR(50),
    IT_Staff_Surname VARCHAR(50),
    IT_Staff_Roles VARCHAR(75),
    PRIMARY KEY (IT_Staff_ID)
);

INSERT INTO IT_Staff(IT_Staff_Code, IT_Staff_Title, IT_Staff_Forname, IT_Staff_Surname, IT_Staff_Roles)
	VALUES('KN', 'Mr', 'Kevin', 'Nickson', 'IT Manager');
    
INSERT INTO IT_Staff(IT_Staff_Code, IT_Staff_Title, IT_Staff_Forname, IT_Staff_Surname, IT_Staff_Roles)
	VALUES('SS', 'Mr', 'Samuel', 'Simpson', 'IT Technician');

INSERT INTO IT_Staff(IT_Staff_Code, IT_Staff_Title, IT_Staff_Forname, IT_Staff_Surname, IT_Staff_Roles)
	VALUES('RG', 'Miss', 'Rachel', 'Green', 'IT Technician');

DROP TABLE IF EXISTS Location; 

CREATE TABLE IF NOT EXISTS Location ( 
	Location_ID INT(10) NOT NULL AUTO_INCREMENT, 
    Room_Number VARCHAR(5), 
    Building VARCHAR(25),
	PRIMARY KEY (Location_ID)
);

INSERT INTO Location(Room_Number, Building)
	VALUES('A1', 'SLT Corridor');

INSERT INTO Location(Room_Number, Building)
	VALUES('A2', 'SLT Corridor');

INSERT INTO Location(Room_Number, Building)
	VALUES('A3', 'SLT Corridor');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('A4', 'SLT Corridor');

INSERT INTO Location(Room_Number, Building)
	VALUES('A5', 'SLT Corridor');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('A6', 'SLT Corridor');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('A7', 'SLT Corridor');
      
INSERT INTO Location(Room_Number, Building)
	VALUES('L1', 'Languages');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('L2', 'Languages');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('L3', 'Languages');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('L4', 'Languages');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M5', 'Main Building');

INSERT INTO Location(Room_Number, Building)
	VALUES('M6', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M7', 'Main Building');

INSERT INTO Location(Room_Number, Building)
	VALUES('M8', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M9', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M10', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M11', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M12', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M13', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M14', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M15', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('M16', 'Main Building');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('MA1', 'Mathematics');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('MA2', 'Mathematics');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('MA3', 'Mathematics');

INSERT INTO Location(Room_Number, Building)
	VALUES('MA4', 'Mathematics');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('MA5', 'Mathematics');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('MA6', 'Mathematics');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('H1', 'Humanities');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('H2', 'Humanities');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('H3', 'Humanities');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('H4', 'Humanities');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('H5', 'Humanities');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('PA1', 'Performing Arts');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('PA2', 'Performing Arts');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('S1', 'Science');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('S2', 'Science');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('S3', 'Science');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('S4', 'Science');
    
INSERT INTO Location(Room_Number, Building)
	VALUES('S5', 'Science');
    
DROP TABLE IF EXISTS Equipment; 

CREATE TABLE IF NOT EXISTS Equipment (
	Equipment_ID INT(10) NOT NULL AUTO_INCREMENT,
    Equipment_Name VARCHAR(25),
    Equipment_Brand VARCHAR(10),
    Date_Purchased DATE,
    Serial_Number INT(5),
    Location_ID INT(10),
    PRIMARY KEY (Equipment_ID)
);

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10001', '1');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10002', '2');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10003', '3');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10004', '4');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10005', '5');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10006', '6');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10007', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10008', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10009', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10010', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10011', '8');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10012', '9');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10013', '10');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10014', '11');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10015', '12');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10016', '13');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10017', '14');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10018', '15');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10019', '16');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10020', '17');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10021', '18');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10022', '19');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10023', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10024', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10025', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10026', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10027', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10028', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10029', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10030', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10031', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10032', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10033', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10034', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10035', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10036', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Dell', '2017-08-01', '10037', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14301', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14302', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14303', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14304', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14305', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14306', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14307', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14308', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14309', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14310', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14311', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14312', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14313', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14314', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14315', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14316', '37');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14317', '38');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14318', '39');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14319', '40');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'HP', '2016-08-21', '14320', '41');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12101', '22');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12102', '24');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12103', '25');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12104', '26');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12105', '27');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12106', '28');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12107', '29');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12108', '30');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12109', '31');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12110', '32');
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12111', '33');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12112', '34');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12113', '35');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Logitech', '2014-08-30', '12114', '36');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Apple', '2018-08-18', '01001', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Apple', '2018-08-18', '01002', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Apple', '2018-08-18', '01003', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Apple', '2018-08-18', '01004', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Monitor', 'Apple', '2018-08-18', '01005', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20001', '1');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20002', '2');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20003', '3');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20004', '4');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20005', '5');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20006', '6');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20007', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20008', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20009', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20010', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20011', '8');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20012', '9');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20013', '10');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20014', '11');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20015', '12');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20016', '13');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20017', '14');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20018', '15');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20019', '16');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20020', '17');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20021', '18');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20022', '19');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20023', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20024', '20');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20025', '20');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20026', '20');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20027', '20');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20028', '20');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20029', '20');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20030', '20');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20031', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20032', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20033', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20034', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20035', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20036', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Dell', '2017-08-01', '20037', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24301', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24302', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24303', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24304', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24305', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24306', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24307', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24308', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24309', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24310', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24311', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24312', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24313', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24314', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24315', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24316', '37');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24317', '38');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24318', '39');
        
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24319', '40');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'HP', '2016-08-21', '24320', '41');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22101', '22');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22102', '24');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22103', '25');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22104', '26');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22105', '27');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22106', '28');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22107', '29');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22108', '30');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22109', '31');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22110', '32');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22111', '33');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22112', '34');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22113', '35');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Logitech', '2014-08-30', '22114', '36');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Apple', '2018-08-18', '02001', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Apple', '2018-08-18', '02002', '23');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Apple', '2018-08-18', '02003', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Apple', '2018-08-18', '02004', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Keyboard', 'Apple', '2018-08-18', '02005', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30001', '1');  
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30002', '2');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30003', '3');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30004', '4');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30005', '5');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30006', '6');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30007', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30008', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30009', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30010', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30011', '8');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30012', '9');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30013', '10');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30014', '11');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30015', '12');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30016', '13');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30017', '14');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30018', '15');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30019', '16');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30020', '17');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30021', '18');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30022', '19');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30023', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30024', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30025', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30026', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30027', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30028', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30029', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30030', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30031', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30032', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30033', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30034', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30035', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30036', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Dell', '2017-08-01', '30037', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34301', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34302', '21');   

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34303', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34304', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34305', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34306', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34307', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34308', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34309', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34310', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34311', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34312', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34313', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34314', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34315', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34316', '37');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34317', '38');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34318', '39');
 
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34319', '40'); 
 
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'HP', '2016-08-21', '34320', '41');
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32101', '22');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32102', '24');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32103', '25');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32104', '26');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32105', '27');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32106', '28');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32107', '29');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32108', '30');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32109', '31');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32110', '32');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32111', '33');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32112', '34');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32113', '35');   
   
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Logitech', '2014-08-30', '32114', '36');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Apple', '2018-08-18', '03001', '23');
       
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Apple', '2018-08-18', '03002', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Apple', '2018-08-18', '03003', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Apple', '2018-08-18', '03004', '23');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Mouse', 'Apple', '2018-08-18', '03005', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40001', '1');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40002', '2');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40003', '3');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40004', '4');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40005', '5');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40006', '6');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40007', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40008', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40009', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40010', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40011', '8');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40012', '9');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40013', '10');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40014', '11');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40015', '12');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40016', '13');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40017', '14');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40018', '15');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40019', '16');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40020', '17');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40021', '18');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40022', '19');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40023', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40024', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40025', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40026', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40027', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40028', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40029', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40030', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40031', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40032', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40033', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40034', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40035', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40036', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Dell', '2017-08-01', '40037', '20');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44301', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44302', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44303', '21');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44304', '21');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44305', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44306', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44307', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44308', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44309', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44310', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44311', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44312', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44313', '21');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44314', '21'); 
 
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44315', '21'); 
 
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44316', '37');
 
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44317', '38');
 
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44318', '39');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44319', '40');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'HP', '2016-08-01', '44320', '41');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42101', '22');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42102', '24'); 
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42103', '25');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42104', '26');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42105', '27');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42106', '28');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42107', '29');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42108', '30');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42109', '31');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42110', '32');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42111', '33');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42112', '34');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42113', '35');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Logitech', '2014-08-30', '42114', '36');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Apple', '2018-08-18', '04001', '23'); 
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Apple', '2018-08-18', '04002', '23');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Apple', '2018-08-18', '04003', '23');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Apple', '2018-08-18', '04004', '23');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('System Unit', 'Apple', '2018-08-18', '04005', '23');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72301', '8');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72302', '9');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72303', '10');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72304', '11');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72305', '12');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72306', '13');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72307', '14');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72308', '15');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72309', '16');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72310', '17');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72311', '18');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72312', '19');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72313', '20');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72314', '21');    

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72315', '22');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72316', '23');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72317', '37');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72318', '38');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72319', '39');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72320', '40');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72321', '41');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72322', '24');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72323', '25');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72324', '26');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72325', '27');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72326', '28');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72327', '29');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72328', '30');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72329', '31');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72330', '32');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72331', '33');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72332', '34');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72333', '35');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Interactive Projector', 'Epson', '2015-08-05', '72334', '36');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Printer', 'Epson', '2013-08-27', '98001', '1');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Printer', 'Epson', '2013-08-27', '98002', '23');     
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Printer', 'Epson', '2013-08-27', '46201', '35');     
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Printer', 'Epson', '2013-08-27', '46202', '30');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Printer', 'Epson', '2013-08-27', '46203', '24');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Printer', 'Epson', '2013-08-27', '46204', '37');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54001', '7');   
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54002', '7');      
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54003', '7');      
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54004', '7');      
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54005', '7');  
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54006', '7');  
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54007', '7');      
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54008', '7');      
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54009', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'Dell', '2017-09-01', '54010', '7');      
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79201', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79202', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79203', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79204', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79205', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79206', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79207', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79208', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79209', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Laptop', 'HP', '2015-09-12', '79210', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67401', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67402', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67403', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67404', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67405', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67406', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67407', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67408', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67409', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67410', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67411', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67412', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67413', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67414', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67415', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67416', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67417', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67418', '7');
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67419', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67420', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67421', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67422', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67423', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67424', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67425', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67426', '7');    
    
INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67427', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67428', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67429', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67430', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67431', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67432', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67433', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67434', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67435', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67436', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67437', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67438', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67439', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67440', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67441', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67442', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67443', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67444', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67445', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67446', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67447', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67448', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67449', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67450', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67451', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67452', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67453', '7');

INSERT INTO Equipment(Equipment_Name, Equipment_Brand, Date_Purchased, Serial_Number, Location_ID)
	VALUES('Two-Way Radio', 'Motorola', '2017-08-05', '67454', '7');

DROP TABLE IF EXISTS Tickets;

CREATE TABLE IF NOT EXISTS Tickets (
	Ticket_ID INT(10) NOT NULL AUTO_INCREMENT,
    Date_Opened DATE,
    Category ENUM('Hardware', 'Software', 'IT'),
    Category_Type VARCHAR(25),
    Problem_Description VARCHAR(150),
    Priority ENUM('High', 'Medium', 'Low'),
    Resolved ENUM('Y', 'N'),
    Action_Taken VARCHAR(100),
    Date_Closed DATE, 
    IT_Staff_ID INT(10), 
    Staff_ID INT(10), 
    PRIMARY KEY (Ticket_ID)
);

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-17', 'Software', 'Monitor', 'UI does not appear on screen', 'Medium', 'Y', 'HDMI cable fully inserted into socket', '2018-12-17', '1', '1');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-17', 'Software', 'SIMS', 'Can not take the register', 'High', 'Y', 'Needed to log in as a different teacher', '2018-12-17', '3','18');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-18', 'Hardware', 'Systems Unit', 'The computer will not turn on', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-14', '2', '21');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-19', 'Software', 'Interactive Projector', 'Even though the sound and the Interactive Projector pen work, the Interactive projector will not display an image.', 'High', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-07', '3', '37');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-19', 'Software', 'MicrosoftOffice', 'Can not log on to the email', 'Medium', 'Y', 'Re-set the password', '2018-12-19', '2', '48');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-20', 'Software', 'Printer', 'The device does not allow them to log on', 'Low', 'Y', 'Re-set the password', '2018-12-19', '1', '8');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-20', 'Software', 'Mouse', 'The mouse does not move the on-screen clicker on the user interface', 'Medium', 'Y', 'Re-plugged the device as not fully plugged in', '2018-12-20', '2', '39');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-20', 'Hardware', 'Keyboard', 'Some of the letter keys do not work', 'High', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-14', '3', '47');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-20', 'Hardware', 'Monitor', 'Monitor will not turn on', 'High', 'Y', 'Power cable fully inserted into socket', '2018-12-20', '2', '32');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2018-12-21', 'Hardware', 'Laptop', 'The mouse pad does not work', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-14', '1', '38');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-07', 'Hardware', 'Two-way radio', 'The radio cannot receive/ send messages', 'Medium', 'Y', 'The wavelength nozzle had been altered to moved to original place', '2019-01-07', '3', '27');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-07', 'Hardware', 'Two-way radio', 'The radio can receive but not send messaged', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-14', '1', '44');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-07', 'Software', 'MicrosoftOffice', 'Can not log on to the email', 'Low', 'Y', 'Re-set the password', '2019-01-07', '2', '23');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-07', 'Software', 'Printer', 'Users cannot connect to the device', 'Medium', 'Y', 'The printer was re-set and then devices could connect to it', '2019-01-07', '1', '14');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-07', 'Hardware', 'Mouse', 'The scroller on the mouse does not work', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-14', '3', '16');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-08', 'Hardware', 'Keyboard', 'Some of the letter keys do not work', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2018-12-19', '2', '6');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-08', 'Hardware', 'Monitor', 'The monitor fell on the floor and cracked', 'High', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-14', '3', '35');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-08', 'Hardware', 'Systems Unit', 'The unit is processing really slowly', 'Low', 'Y', 'Re-set the device', '2019-01-08', '1', '31');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-08','Hardware', 'Two-way radio', 'The radio cannot receive/ send messages', 'Medium', 'Y', 'The wavelength nozzle had been altered to moved to original place', '2019-01-08', '2', '48');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-09', 'Hardware', 'Systems Unit', 'The unit is processing really slowly', 'Low', 'Y', 'Re-set the device', '2019-01-19', '1', '51');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-09', 'Software', 'MicrosoftOffice', 'Can not log on to SIMS', 'Low', 'Y', 'Re-set the password', '2019-01-09', '3', '12');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-10', 'Software', 'SIMS', 'Can not find my class register', 'High', 'Y', 'Added class to teachers register', '2019-01-10', '1', '18');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-10', 'Hardware', 'Two-way radio', 'The radio cannot receive/ send messages', 'Medium', 'Y', 'The wavelength nozzle had been altered to moved to original place', '2019-01-10', '2', '28');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-10', 'Software', 'Monitor', 'UI does not appear on screen', 'Medium', 'Y', 'HDMI cable fully inserted into socket', '2019-01-10', '3', '34');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-10', 'Hardware', 'Keyboard', 'Some of the letter keys do not work', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-14', '2', '42');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-11', 'Software', 'Laptop', 'My laptop is not printing again, I have tried to install that Paper MF, but nothing is happening', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-14', '2', '36');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-11', 'IT', 'Internet Access', 'Could you check the internet access for a pupil in year 11 - shes tried to access the internet period 3 but can not get on.', 'Low', 'Y', 'Pupil had been added to the internet ban list by a member of staff, now removed', '2019-11-01', '1', '33');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-14', 'IT', 'Printer', 'When printing to the main building printer, there is a solid black line being produced on the printouts', 'Low', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-21', '1', '7');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-14', 'Software', 'Laptop', 'He is unable to print any work off his laptop. The message says that it is off line and just keeps asking it to save', 'Medium', 'Y', 'No printers were installed. I have now installed them remotely', '2019-01-14', '3', '45');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-14', 'Hardware', 'Two-way radio', 'Two-way radio has dies', 'Medium', 'Y', 'Fitted new batteries', '2019-01-14', '2', '30');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-14', 'Software', 'SIMS', 'Please install SIMS on three PCs in M14 so I can train staff after school on 17th January', 'High', 'Y', 'Installed', '2019-01-14', '3', '32');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-15', 'IT', 'YouTube', 'Unblock youtube for one lesson P3', 'Low', 'Y', 'YouTube unlocked for lesson', '2019-01-15', '2', '44');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-16', 'Software', 'Monitor', 'Screen is not working - its just blue', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-21', '1', '25');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-16', 'Software', 'MicrosoftOffice', 'Powerpoint wont open and when it finally does it just crashes', 'High', 'Y', 'Uninstalled and Installed Powerpoint', '2019-01-16', '1', '11');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-16', 'IT', 'Laptop', 'Unable to open the remote access portal', 'Low', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-21', '2', '43');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-16', 'Software', 'SIMS', 'Run census patch this evening', 'High', 'Y', 'Ran Census', '2019-01-16', '1', '51');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-17', 'IT', 'Printer', 'SLT corridor printer has a misfeed', 'High', 'Y', 'Reset Printer', '2019-01-17', '3', '47');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-17', 'Hardware', 'Interactive Projector', 'The projector remote is not working. Ive tried changing the batteries but this has made no difference', 'Medium', 'Y', 'Took back to manufactuer and it is now fixed', '2019-01-28', '2', '16');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-17', 'Hardware', 'Printer', 'The printer needs a new Cyan toner', 'Medium', 'Y', 'Replaced toner', '2019-01-17', '2', '22');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-18', 'Hardware', 'Interactive Projector', 'Can’t switch on the interactive whiteboard', 'Low', 'Y', 'Re-plugged the device as not fully plugged in', '2019-01-17', '1', '9');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-21', 'Software', 'Systems Unit', 'Can’t print from a website, printing fine from word', 'High', 'Y', 'Reset Internet explorer then it worked', '2019-01-21', '2', '5');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-21', 'IT', 'YouTube', 'Unblock youtube for one lesson P4', 'Low', 'Y', 'YouTube unlocked for lesson', '2019-01-21', '3', '40');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-21', 'IT', 'Folders', 'Acidentially deleted some files from the science folder, "unit 10 - using resources", retrieve files if possible.', 'High', 'Y', 'Files retrieved', '2019-01-21', '1', '19');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-21', 'Hardware', 'Printer', 'Replace the black toner cartridge', 'Medium', 'Y', 'Replaced toner', '2019-01-21', '2', '15');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-22', 'IT', 'Folders', 'Assign folder permissions for staff folders', 'Medium', 'Y', 'Permissions Assigned', '2019-01-22', '1', '29');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-22', 'IT', 'YouTube', 'Unblock youtube for one lesson tomorrow P1', 'Low', 'Y', 'YouTube unlocked for lesson', '2019-01-22', '3', '38');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-23', 'Software', 'Laptop', 'Laptop cannot connect to the printer', 'Low', 'Y', 'Reset device, can now connect', '2019-01-23', '2', '28');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-24', 'Software', 'Systems Unit', 'Desktop computer is not connected to the internet. Theres a little computer icon in the corner with a red X on it', 'Medium', 'Y', 'Ethernet cable had come loose, now re-plugged in', '2019-01-24', '2', '36');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-25', 'IT', 'Folders', 'Work Missing from Staff Area folder, please can you locate it', 'Medium', 'Y', 'Files retrieved', '2019-01-25', '3', '28');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-25', 'Software', 'SIMS', 'Unable to log onto SIMS', 'High', 'Y', 'Re-set the password', '2019-01-25', '1', '4');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-28', 'Hardware', 'Two-way radio', 'The speaker has broken', 'High', 'N', 'Took back to manufactuer to be fixed', '00-00-00', '2', '3');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-28', 'Software', 'MicrosoftOffice', 'Word keeps crashing', 'High', 'Y', 'Uninstalled and Installed Word', '2019-01-28', '3', '13');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-29', 'Hardware', 'Keyboard', 'Some of the letter keys do not work', 'High', 'N', 'Took back to manufactuer to be fixed', '00-00-00', '1', '21');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-29', 'Software', 'SIMS', 'Can not find my class register', 'High', 'Y', 'Added class to teachers register', '2019-01-29', '2', '17');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-30', 'IT', 'YouTube', 'Unblock youtube for one lesson P2', 'Low', 'Y', 'YouTube unlocked for lesson', '2019-01-30', '3', '46');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-30', 'Hardware', 'Laptop', 'The mouse pad does not work', 'Medium', 'N', 'Took back to manufactuer to be fixed', '00-00-00', '2', '8');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-30', 'IT', 'Internet Access', 'Could you check the internet access for a pupil in year 8 - hes tried to access the internet period 1 but can not get on.', 'Low', 'Y', 'Pupil had been added to the internet ban list by a member of staff, now removed', '2019-01-30', '1', '31');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-01-31', 'IT', 'Folders', 'Work Missing from Staff Area folder, please can you locate it', 'Medium', 'Y', 'Files retrieved', '2019-01-31', '1', '29');
    
INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-02-01', 'Hardware', 'Mouse', 'The scroller on the mouse does not work', 'Medium', 'N', 'Took back to manufactuer to be fixed', '00-00-00', '3', '33');

INSERT INTO Tickets(Date_Opened, Category, Category_Type, Problem_Description, Priority, Resolved, Action_Taken, Date_Closed, IT_Staff_ID, Staff_ID)
	VALUES('2019-02-01', 'Hardware', 'Printer', 'Replace the yellow toner cartridge', 'Medium', 'Y', 'Replaced toner', '2019-02-01', '2', '50');
        
DROP TABLE IF EXISTS Ticket_Equipment;

CREATE TABLE IF NOT EXISTS Ticket_Equipment (
	Ticket_ID INT(10), 
    Equipment_ID INT(10),
    KEY (Ticket_ID),
    KEY (Equipment_ID)
);

INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('1', '12');

INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('3', '293');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('4', '309');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('6', '343');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('7', '163');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('8', '77');

INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('9', '38');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('10', '347');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('11', '392');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('12', '409');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('14', '343');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('15', '207');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('16', '104');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('17', '122');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('18', '258');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('19', '413');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('20', '234');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('23', '392');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('24', '32');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('25', '87');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('26', '360');

INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('28', '340');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('29', '348');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('30', '394');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('31', '270');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('31', '271');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('31', '272');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('32', '298');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('33', '68');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('35', '355');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('37', '339');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('38', '325');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('39', '342');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('40', '329');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('42', '241');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('44', '344');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('46', '286');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('47', '364');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('48', '304');

INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('51', '367');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('53', '142');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('55', '299');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('59', '181');
    
INSERT INTO Ticket_Equipment (Ticket_ID, Equipment_ID)
	Values('60', '339');
