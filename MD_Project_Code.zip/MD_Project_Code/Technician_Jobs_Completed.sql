use Helpdesk_database; #This identifies which database to use. 
SELECT IT_Staff_Code, COUNT(*) AS Tickets_Completed FROM tickets 
INNER JOIN it_staff ON it_staff.IT_Staff_ID = tickets.IT_Staff_ID
WHERE tickets.Resolved = 'Y'
GROUP BY IT_Staff_Code ASC;
#This selects the IT_Staff_Code attribute and counts the number of tickets that each IT Staff member has 
#by joining the IT_Staff and ticket entities.
#Only the tickets that have Y stored under the resolved attribute are displayed.
#The query is grouped via IT_Staff_Code
