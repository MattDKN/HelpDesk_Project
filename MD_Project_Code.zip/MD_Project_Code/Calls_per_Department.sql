use Helpdesk_database; #This identifies which database to use. 
SELECT staff.Staff_Department, COUNT(*) AS Tickets_Generated FROM tickets 
INNER JOIN staff ON staff.Staff_ID = tickets.Staff_ID 
GROUP BY Staff_Department ASC;
#This selects the Staff_Department attribute and counts the number of tickets that each department has 
#by joining the staff and ticket entities.
#The query output is grouped via Staff_Department.  