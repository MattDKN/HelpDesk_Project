db.myCollection.aggregate([{$group:{_id:"$Category_Type", count:{$sum:1}}},{$sort:{count:-1}}])
/*This uses the aggregate query to count how many of each Category_Type have tickets associated with them.
First the group operator groups the tickets by Category_Type. 
The _id is set to display the values of the Category_Type attribute by using $ before the attribute name. 
Then $sum aggregate operator was used to add the amount of tickets. 
Then the results of the count are sorted in ascending order using the $sort aggregate operator. 
This is achieved by setting count to -1. */