db.myCollection.remove({ Date_Opened:{$lte: new Date((new Date())-1000*60*60*24*365)}})
/* This uses the remove query to delete tickets that have a Date_Opened value of older than a year.
The query contains a condition to remove values from the Date_Opened attribute from a range of values.
The condition is set so that values between the current date, using the new date() function and the 
current date minus a year is less than equal to the Date_Opened attribute. 
*/