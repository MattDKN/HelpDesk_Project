-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: helpdesk_database
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `staff` (
  `Staff_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Staff_Code` varchar(5) DEFAULT NULL,
  `Staff_Title` enum('Dr','Mr','Mrs','Miss','Ms') DEFAULT NULL,
  `Staff_Forname` varchar(50) DEFAULT NULL,
  `Staff_Surname` varchar(50) DEFAULT NULL,
  `Staff_Department` varchar(50) DEFAULT NULL,
  `Staff_Roles` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`Staff_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'FZ','Dr','Fiona','Zeema','English','Head Teacher'),(2,'JW','Mr','Jack','Walsh','English','Head of KS5 English'),(3,'DP','Mrs','Deborah','Parker','English','Head of KS4 English'),(4,'PD','Mr','Peter','Daniels','English','Head of English Department'),(5,'SS','Miss','Sophie','Swift','English','Teacher'),(6,'TJ','Mrs','Tracy','Jones','English','Teacher'),(7,'ALC','Mr','Andrew','Lawrence-Cunningham','English','Teacher'),(8,'NH','Mrs','Nicola','Hay','Maths','Assistant-Head Teacher'),(9,'CF','Mr','Christopher','Foster','Maths','Head of KS5 Maths'),(10,'MG','Mr','Micheal','Gledhill','Maths','Head of Maths Department'),(11,'ED','Mrs','Elise','Donaldson','Maths','Teacher'),(12,'LS','Mr','Liam','Smith','Maths','Head of KS4 Maths'),(13,'KR','Mr','Kasper','Rowlinson','Maths','Teacher'),(14,'AH','Mr','Anthony','Hay','Science','Head of Science Department'),(15,'NN','Mr','Nigel','Newns','Science','Head of KS4 Science'),(16,'AA','Ms','Amy','Armstrong','Science','Teacher'),(17,'AMQ','Mr','Arther','McQuillian','Science','Head of KS5 Science'),(18,'CW','Miss','Caitlin','Walton','Science','Teacher'),(19,'KW','Mrs','Karren','Wilson','Science','Teacher'),(20,'BJ','Mr','Benjamin','James','Humanities','Head of Geography Department'),(21,'EJ','Mrs','Elizibeth','Jenkins','Humanities','Head of History Department'),(22,'EC','Ms','Elaine','Chadwick','Humanities','Head of Religious Studies'),(23,'PB','Mr','Patrick','Brown','Humanities','Teacher'),(24,'VA','Miss','Victoria','Appleton','Humanities','Teacher'),(25,'IR','Miss','Iola','Roberts','P.E.','Head of KS5 Physical Education'),(26,'CC','Miss','Chloe','Chadwick','P.E.','Teacher'),(27,'EH','Mrs','Emily','Hughes','P.E.','Head of Physical Education Department'),(28,'IB','Mr','Ian','Braithwaite','P.E.','Head of KS4 Physical Education'),(29,'IB','Mr','Ian','Braithwaite','P.E.','Head of KS4 Physical Education'),(30,'DH','Mr','David','Hill','Business, IT & Media','Head of IT Department'),(31,'IF','Mrs','Isabelle','Fleetwood','Business, IT & Media','Teacher'),(32,'JH','Mr','James','Holden','Business, IT & Media','Head of Business Department'),(33,'CS','Miss','Courtney','Sharpe','Psychology & Law','Head of KS5 Psychology & Law'),(34,'DT','Mr','Daniel','Thatcher','Psychology & Law','Head of Psychology & Law Department'),(35,'CL','Mr','Craig','Livingstone','Psychology & Law','Head of KS4 Psychology & Law'),(36,'HJ','Ms','Helen','Jones','Languages','Head of Languages Department'),(37,'EB','Ms','Ella','Burrows','Languages','Head of KS5 Languages'),(38,'EM','Mrs','Emily','Muller','Languages','Head of KS4 Languages'),(39,'TLC','Mr','Thierry','La Costa','Languages','Teacher'),(40,'MW','Mr','Matthew','Whitehall','Languages','Teacher'),(41,'TH','Mr','Thomas','Harris','Performing Arts','Head of Performing Arts Department'),(42,'JM','Miss','Jennifer','Myles','Performing Arts','Teacher'),(43,'RM','Mrs','Rebecca','Maguire','Performing Arts','Teacher'),(44,'NC','Mrs','Nicola','Calderbank','Administration','Exams Officer'),(45,'HK','Ms','Heather','Kannaird','Administration','Office Manager'),(46,'RR','Mr','Ralph','Roberts','Administration','Finance Administrator'),(47,'PE','Miss','Paula','Evans','Administration','Events Coordinator'),(48,'EE','Mrs','Eugine','Edwards','Administration','Administative assistant');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-28 19:27:39
