-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: helpdesk_database
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tickets` (
  `Ticket_ID` int(10) NOT NULL AUTO_INCREMENT,
  `Date_Opened` date DEFAULT NULL,
  `Category` enum('Hardware','Software','IT') DEFAULT NULL,
  `Category_Type` varchar(25) DEFAULT NULL,
  `Problem_Description` varchar(150) DEFAULT NULL,
  `Priority` enum('High','Medium','Low') DEFAULT NULL,
  `Resolved` enum('Y','N') DEFAULT NULL,
  `Action_Taken` varchar(100) DEFAULT NULL,
  `Date_Closed` date DEFAULT NULL,
  `IT_Staff_ID` int(10) DEFAULT NULL,
  `Staff_ID` int(10) DEFAULT NULL,
  PRIMARY KEY (`Ticket_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,'2018-12-17','Software','Monitor','UI does not appear on screen','Medium','Y','HDMI cable fully inserted into socket','2018-12-17',1,1),(2,'2018-12-17','Software','SIMS','Can not take the register','High','Y','Needed to log in as a different teacher','2018-12-17',3,18),(3,'2018-12-18','Hardware','Systems Unit','The computer will not turn on','Medium','Y','Took back to manufactuer and it is now fixed','2019-01-14',2,21),(4,'2018-12-19','Software','Interactive Projector','Even though the sound and the Interactive Projector pen work, the Interactive projector will not display an image.','High','Y','Took back to manufactuer and it is now fixed','2019-01-07',3,37),(5,'2018-12-19','Software','MicrosoftOffice','Can not log on to the email','Medium','Y','Re-set the password','2018-12-19',2,48),(6,'2018-12-20','Software','Printer','The device does not allow them to log on','Low','Y','Re-set the password','2018-12-19',1,8),(7,'2018-12-20','Software','Mouse','The mouse does not move the on-screen clicker on the user interface','Medium','Y','Re-plugged the device as not fully plugged in','2018-12-20',2,39),(8,'2018-12-20','Hardware','Keyboard','Some of the letter keys do not work','High','Y','Took back to manufactuer and it is now fixed','2019-01-14',3,47),(9,'2018-12-20','Hardware','Monitor','Monitor will not turn on','High','Y','Power cable fully inserted into socket','2018-12-20',2,32),(10,'2018-12-21','Hardware','Laptop','The mouse pad does not work','Medium','Y','Took back to manufactuer and it is now fixed','2019-01-14',1,38),(11,'2019-01-07','Hardware','Two-way radio','The radio cannot receive/ send messages','Medium','Y','The wavelength nozzle had been altered to moved to original place','2019-01-07',3,27),(12,'2019-01-07','Hardware','Two-way radio','The radio can receive but not send messaged','Medium','Y','Took back to manufactuer and it is now fixed','2019-01-14',1,44),(13,'2019-01-07','Software','MicrosoftOffice','Can not log on to the email','Low','Y','Re-set the password','2019-01-07',2,23),(14,'2019-01-07','Software','Printer','Users cannot connect to the device','Medium','Y','The printer was re-set and then devices could connect to it','2019-01-07',1,14),(15,'2019-01-07','Hardware','Mouse','The scroller on the mouse does not work','Medium','Y','Took back to manufactuer and it is now fixed','2019-01-14',3,16),(16,'2019-01-08','Hardware','Keyboard','Some of the letter keys do not work','Medium','Y','Took back to manufactuer and it is now fixed','2018-12-19',2,6),(17,'2019-01-08','Hardware','Monitor','The monitor fell on the floor and cracked','High','Y','Took back to manufactuer and it is now fixed','2019-01-14',3,35),(18,'2019-01-08','Hardware','Systems Unit','The unit is processing really slowly','Low','Y','Re-set the device','2019-01-08',1,31),(19,'2019-01-08','Hardware','Two-way radio','The radio cannot receive/ send messages','Medium','Y','The wavelength nozzle had been altered to moved to original place','2019-01-08',2,48),(20,'2019-01-09','Hardware','Systems Unit','The unit is processing really slowly','Low','Y','Re-set the device','2019-01-19',1,51),(21,'2019-01-09','Software','MicrosoftOffice','Can not log on to SIMS','Low','Y','Re-set the password','2019-01-09',3,12),(22,'2019-01-10','Software','SIMS','Can not find my class register','High','Y','Added class to teachers register','2019-01-10',1,18),(23,'2019-01-10','Hardware','Two-way radio','The radio cannot receive/ send messages','Medium','Y','The wavelength nozzle had been altered to moved to original place','2019-01-10',2,28),(24,'2019-01-10','Software','Monitor','UI does not appear on screen','Medium','Y','HDMI cable fully inserted into socket','2019-01-10',3,34),(25,'2019-01-10','Hardware','Keyboard','Some of the letter keys do not work','Medium','Y','Took back to manufactuer and it is now fixed','2019-01-14',2,42),(26,'2019-01-11','Software','Laptop','My laptop is not printing again, I have tried to install that Paper MF, but nothing is happening','Medium','Y','Took back to manufactuer and it is now fixed','2019-01-14',2,36),(27,'2019-01-11','IT','Internet Access','Could you check the internet access for a pupil in year 11 - shes tried to access the internet period 3 but can not get on.','Low','Y','Pupil had been added to the internet ban list by a member of staff, now removed','2019-11-01',1,33),(28,'2019-01-14','IT','Printer','When printing to the main building printer, there is a solid black line being produced on the printouts','Low','Y','Took back to manufactuer and it is now fixed','2019-01-21',1,7),(29,'2019-01-14','Software','Laptop','He is unable to print any work off his laptop. The message says that it is off line and just keeps asking it to save','Medium','Y','No printers were installed. I have now installed them remotely','2019-01-14',3,45),(30,'2019-01-14','Hardware','Two-way radio','Two-way radio has dies','Medium','Y','Fitted new batteries','2019-01-14',2,30),(31,'2019-01-14','Software','SIMS','Please install SIMS on three PCs in M14 so I can train staff after school on 17th January','High','Y','Installed','2019-01-14',3,32),(32,'2019-01-15','IT','YouTube','Unblock youtube for one lesson P3','Low','Y','YouTube unlocked for lesson','2019-01-15',2,44),(33,'2019-01-16','Software','Monitor','Screen is not working - its just blue','Medium','Y','Took back to manufactuer and it is now fixed','2019-01-21',1,25),(34,'2019-01-16','Software','MicrosoftOffice','Powerpoint wont open and when it finally does it just crashes','High','Y','Uninstalled and Installed Powerpoint','2019-01-16',1,11),(35,'2019-01-16','IT','Laptop','Unable to open the remote access portal','Low','Y','Took back to manufactuer and it is now fixed','2019-01-21',2,43),(36,'2019-01-16','Software','SIMS','Run census patch this evening','High','Y','Ran Census','2019-01-16',1,51),(37,'2019-01-17','IT','Printer','SLT corridor printer has a misfeed','High','Y','Reset Printer','2019-01-17',3,47),(38,'2019-01-17','Hardware','Interactive Projector','The projector remote is not working. Ive tried changing the batteries but this has made no difference','Medium','Y','Took back to manufactuer and it is now fixed','2019-01-28',2,16),(39,'2019-01-17','Hardware','Printer','The printer needs a new Cyan toner','Medium','Y','Replaced toner','2019-01-17',2,22),(40,'2019-01-18','Hardware','Interactive Projector','Can’t switch on the interactive whiteboard','Low','Y','Re-plugged the device as not fully plugged in','2019-01-17',1,9),(41,'2019-01-21','Software','Systems Unit','Can’t print from a website, printing fine from word','High','Y','Reset Internet explorer then it worked','2019-01-21',2,5),(42,'2019-01-21','IT','YouTube','Unblock youtube for one lesson P4','Low','Y','YouTube unlocked for lesson','2019-01-21',3,40),(43,'2019-01-21','IT','Folders','Acidentially deleted some files from the science folder, \"unit 10 - using resources\", retrieve files if possible.','High','Y','Files retrieved','2019-01-21',1,19),(44,'2019-01-21','Hardware','Printer','Replace the black toner cartridge','Medium','Y','Replaced toner','2019-01-21',2,15),(45,'2019-01-22','IT','Folders','Assign folder permissions for staff folders','Medium','Y','Permissions Assigned','2019-01-22',1,29),(46,'2019-01-22','IT','YouTube','Unblock youtube for one lesson tomorrow P1','Low','Y','YouTube unlocked for lesson','2019-01-22',3,38),(47,'2019-01-23','Software','Laptop','Laptop cannot connect to the printer','Low','Y','Reset device, can now connect','2019-01-23',2,28),(48,'2019-01-24','Software','Systems Unit','Desktop computer is not connected to the internet. Theres a little computer icon in the corner with a red X on it','Medium','Y','Ethernet cable had come loose, now re-plugged in','2019-01-24',2,36),(49,'2019-01-25','IT','Folders','Work Missing from Staff Area folder, please can you locate it','Medium','Y','Files retrieved','2019-01-25',3,28),(50,'2019-01-25','Software','SIMS','Unable to log onto SIMS','High','Y','Re-set the password','2019-01-25',1,4),(51,'2019-01-28','Hardware','Two-way radio','The speaker has broken','High','N','Took back to manufactuer to be fixed','0000-00-00',2,3),(52,'2019-01-28','Software','MicrosoftOffice','Word keeps crashing','High','Y','Uninstalled and Installed Word','2019-01-28',3,13),(53,'2019-01-29','Hardware','Keyboard','Some of the letter keys do not work','High','N','Took back to manufactuer to be fixed','0000-00-00',1,21),(54,'2019-01-29','Software','SIMS','Can not find my class register','High','Y','Added class to teachers register','2019-01-29',2,17),(55,'2019-01-30','IT','YouTube','Unblock youtube for one lesson P2','Low','Y','YouTube unlocked for lesson','2019-01-30',3,46),(56,'2019-01-30','Hardware','Laptop','The mouse pad does not work','Medium','N','Took back to manufactuer to be fixed','0000-00-00',2,8),(57,'2019-01-30','IT','Internet Access','Could you check the internet access for a pupil in year 8 - hes tried to access the internet period 1 but can not get on.','Low','Y','Pupil had been added to the internet ban list by a member of staff, now removed','2019-01-30',1,31),(58,'2019-01-31','IT','Folders','Work Missing from Staff Area folder, please can you locate it','Medium','Y','Files retrieved','2019-01-31',1,29),(59,'2019-02-01','Hardware','Mouse','The scroller on the mouse does not work','Medium','N','Took back to manufactuer to be fixed','0000-00-00',3,33),(60,'2019-02-01','Hardware','Printer','Replace the yellow toner cartridge','Medium','Y','Replaced toner','2019-02-01',2,50);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-28 19:27:36
