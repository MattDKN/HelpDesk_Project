use Helpdesk_database; #This identifies which database to use. 
SELECT tickets.Category_Type, COUNT(*) AS Jobs FROM tickets GROUP BY Category_Type ORDER BY Jobs DESC;
#This selects the Category_Type attribute and counts the number of tickets that each Category_Type has.
#The query is ordered by the column that counts the tickets, which is names jobs. 