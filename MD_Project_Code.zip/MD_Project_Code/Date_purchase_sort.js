db.myCollection.find({"Date_purchased":{$ne:""}},
{"Ticket_ID":1, "Equipment_ID":1, "Equipment_Name":1, "Equipment_brand":1, "Date_purchased":1}).sort({"Date_purchased":1})
/*This uses the find query to select pieces of the equipment in the database that contain a date purchased value 
by pulling the Equipment_ID, Equipment_Name, Equipment_Brand, and Date_purchased attributes.
Then the sort query is used to sort all the returned results in ascending order according to their date_purchased attribute value. 
This is achieved by setting the Date_purchased attribute to 1.*/ 