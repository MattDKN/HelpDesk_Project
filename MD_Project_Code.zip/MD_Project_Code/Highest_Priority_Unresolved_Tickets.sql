use HelpDesk_Database; #This identifies which database to use. 
SELECT * FROM Tickets
WHERE Resolved = 'N'
Order by Priority AND Date_Opened ASC;
#This selects all the attributes from the tickets entity under the condition that the resolved field = N.
#This query is then ordered by priority attritute first, then the Date_Opened attribute. 