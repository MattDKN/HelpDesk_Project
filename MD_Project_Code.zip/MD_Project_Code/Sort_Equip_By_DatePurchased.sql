use helpdesk_database; #This identifies which database to use. 
SELECT * FROM Equipment 
Order by Date_Purchased 
# This selects all the attributes from the Equipment table and orders them by the Date_Purchased attribute. 
