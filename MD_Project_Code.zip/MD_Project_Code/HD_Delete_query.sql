Use HelpDesk_Database; #This identifies which database to use. 
DELETE FROM Tickets WHERE Date_Opened < NOW() - INTERVAL 365 DAY; 
#This deletes values from the ticket table where the Date_Opened attribute is less than the current date minus 365 days.  