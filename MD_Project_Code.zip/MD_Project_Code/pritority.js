db.myCollection.find({"Resolved":"N"},
{"Ticket_ID":1, "Date_opened":1, "Category": 1, "Category_Type": 1, "Problem_Description": 1, "Priority":1})
.sort({"Priority":1})
/*This uses the find query to select tickets in the database that are not resolved by pulling the 
Ticket_ID, Date_opened, Category, Category_Type, Problem_Description and Priority attributes.
Then the sort query is used to sort all the returned results in ascending order, stating high priority jobs first, 
according to their priority attribute value. 
This is achieved by setting the priority attribute to 1.*/ 