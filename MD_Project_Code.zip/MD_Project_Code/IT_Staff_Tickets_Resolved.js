db.myCollection.aggregate([
{$match: {"Resolved": "Y"}},
{$group:{_id:"$IT_Staff_Code", sum:{$sum:1}}}])
/*This uses the aggregate query to count how many tickets each Technician has resolved.
First the match operator is used to define that only tickets that store the "Y" value in the Resovled category. 
The group operator groups the tickets by IT_Staff_Code. 
The _id is set to display the values of the IT_Staff_Code by using $ before the attribute name. 
Then $sum aggregate operator was used to add up the amount of tickets. 
This is set to 1 to display the results as positive.*/
